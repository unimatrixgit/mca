Dune Guild Lobby 1.1.0 | Paper 1.21.4 | Java 21 | Interiors only

Extract into a STOPPED dedicated lobby server directory. Do not overwrite an existing guild_lobby.
Install ImageFrame 2026.1.5.0: python tools/install_imageframe.py <server-directory>
Keep level-name=lobby_bootstrap (or another primary world); do not set level-name=guild_lobby.
Start Paper; DuneLobby imports guild_lobby as THE_END, restores artwork, and routes joins.
Run dunelobby verify from console. Players use /lobby.
Read README-Guild-Lobby.md for proxy destinations, optional DuneCore/DuneEss integration and barter rules.
Source and current instructions: https://github.com/unimatrixgit/mcdune/tree/beta/DuneLobby
